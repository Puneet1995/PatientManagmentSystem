
<html>

<head>
<title></title>
</head>

<body >
<FORM ENCTYPE="multipart/form-data" ACTION="addimg.php" METHOD=POST>
Upload this file: <INPUT NAME="userfile" TYPE="file">
<INPUT TYPE="submit" VALUE="Send File"></FORM>

</body>

</html>
