<?php
$server='localhost';
$user='root';
$pass='root';
$db='HMS';
$admin='ITS6801';
?>
