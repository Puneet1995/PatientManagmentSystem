module Bootstrap
  VERSION       = '3.3.5'
  BOOTSTRAP_SHA = '16b48259a62f576e52c903c476bd42b90ab22482'
end
